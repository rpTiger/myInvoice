<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sales List</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- DataTable CSS -->
  <link href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
  
  <style>
    .print-btn, .action-btn, .delete-btn {
      text-decoration: none;
      border-radius: 5px;
      padding: 8px 12px;
      font-size: 14px;
      color: white;
    }
    .print-btn {
      background-color: #4CAF50; /* Green */
    }
    .print-btn:hover {
      background-color: #45a049;
    }
    .action-btn {
      background-color: #2196F3; /* Blue */
    }
    .action-btn:hover {
      background-color: #0b7dda;
    }
    .delete-btn {
      background-color: #f44336; /* Red */
    }
    .delete-btn:hover {
      background-color: #d32f2f;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <h2 class="mb-4">Sales Records</h2>
    <!-- Add New Sale Button -->
    <a href="add-sales.php" class="btn btn-primary mb-4">Add New Sale</a>
    
    <!-- Sales Table -->
    <table id="salesTable" class="table table-bordered table-striped">
      <thead class="table-light">
        <tr>
          <th>No.</th>  
          <th>Sale ID</th>
          <th>Name</th>
          <th>Date</th>
          <th>Total</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <!-- Dynamic rows will be added here -->
      </tbody>
    </table>
  </div>

  <!-- Bootstrap JS and Popper.js (for Bootstrap components like tooltips) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <!-- jQuery (necessary for DataTables plugin) -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <!-- DataTable JS -->
  <script src="https://cdn.jsdelivr.net/npm/datatables.net@1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@1.11.5/js/dataTables.bootstrap5.min.js"></script>
  
  <script>
    // Fetch sales data from the API
    fetch('api-view-sales.php')
      .then(res => res.json())
      .then(data => {
        const tableBody = document.querySelector('#salesTable tbody');
        if (data.status === 'success') {
          if (data.sales.length > 0) {
            data.sales.forEach((row, index) => {
              const tr = document.createElement('tr');
              tr.innerHTML = `
                <td>${index + 1}</td> <!-- Row number -->
                <td>${row.sale_id}</td>
                <td>${row.sale_name}</td>
                <td>${row.sale_date}</td>
                <td>${row.final_total}</td>
                <td>${row.status}</td>
                <td>
                  <a href="invoice.php?sale_id=${row.id}" target="_blank" class="print-btn">Print Invoice</a>
                  <a href="invoice.php?sale_id=${row.id}" target="_blank" class="print-btn">Print Receipt</a>

                  <a href="edit-sale.php?sale_id=${row.id}" class="action-btn">Edit</a>
                </td>
              `;
              tableBody.appendChild(tr);
            });

            // Initialize DataTable for sorting, pagination, and search
            $('#salesTable').DataTable();
          } else {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center">No records found.</td></tr>';
          }
        } else {
          alert(data.message);
        }
      })
      .catch(err => {
        console.error('Error fetching sales data:', err);
        alert('Failed to load sales data.');
      });
  </script>
</body>
</html>
