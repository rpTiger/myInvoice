<?php
require_once 'db.php';
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

$sale_id = $_POST['sale_id'] ?? '';
$sale_name = $_POST['sale_name'] ?? '';
$sale_phone_no = $_POST['sale_phone_no'] ?? '';
$sale_address = $_POST['sale_address'] ?? '';
$sale_date = $_POST['sale_date'] ?? '';
$total_discount = $_POST['total_discount'] ?? 0;
$status = $_POST['status'] === 'Paid' ? 1 : 0;
$note = $_POST['note'] ?? '';
$item_name = $_POST['item_name'] ?? [];
$item_price = $_POST['item_price'] ?? [];

if (!$sale_id || !$sale_name || !$sale_phone_no || !$sale_date || empty($item_name) || empty($item_price)) {
    die(json_encode(['status' => 'error', 'message' => 'Missing required fields']));
}

// Log input data for debugging purposes
error_log('Sale Data: ' . json_encode([
    'sale_id' => $sale_id, 
    'sale_name' => $sale_name, 
    'sale_phone_no' => $sale_phone_no, 
    'sale_address' => $sale_address,
    'sale_date' => $sale_date,
    'item_name' => $item_name,
    'item_price' => $item_price
]));

$sale_total_amount = array_sum(array_map('floatval', $item_price));
$final_total = $sale_total_amount - floatval($total_discount);

// Update sale record
$sale_sql = "UPDATE sales SET sale_name = ?, sale_address = ?, sale_phone_no = ?, sale_date = ?, sale_total_amount = ?, total_discount = ?, final_total = ?, note = ?, status = ? WHERE id = ?";
$stmt = $conn->prepare($sale_sql);
$stmt->bind_param("ssssdddsdi", $sale_name, $sale_address, $sale_phone_no, $sale_date, $sale_total_amount, $total_discount, $final_total, $note, $status, $sale_id);
$stmt->execute();

// Check if the sale record update was successful
if ($stmt->affected_rows === 0) {
    error_log("Sale update failed for sale_id $sale_id: " . $stmt->error); // Log the error
    die(json_encode(['status' => 'error', 'message' => 'Sale update failed']));
}

// Update items
$item_sql = "DELETE FROM sales_items WHERE sale_id = ?";
$item_stmt = $conn->prepare($item_sql);
$item_stmt->bind_param("i", $sale_id);
$item_stmt->execute();

// Check for deletion errors
if ($item_stmt->error) {
    error_log("Item deletion failed: " . $item_stmt->error); // Log the error
    die(json_encode(['status' => 'error', 'message' => 'Item update failed']));
}

// Insert updated items
$item_sql = "INSERT INTO sales_items (sale_id, item_name, item_price) VALUES (?, ?, ?)";
$item_stmt = $conn->prepare($item_sql);

foreach ($item_name as $i => $name) {
    $price = floatval($item_price[$i]);
    $item_stmt->bind_param("isd", $sale_id, $name, $price);
    if (!$item_stmt->execute()) {
        error_log("Item insertion failed for item $name: " . $item_stmt->error); // Log the error
        die(json_encode(['status' => 'error', 'message' => 'Item update failed']));
    }
}

echo json_encode(['status' => 'success', 'message' => 'Sale updated successfully']);
?>
