<?php
require_once 'db.php';

// Get the sale ID from the URL
$sale_id = $_GET['sale_id'] ?? '';
if (!$sale_id) {
    die("Sale ID is required.");
}

// Fetch sale data from the database based on sale ID
// Assuming $conn is your database connection
$stmt = $conn->prepare("SELECT * FROM sales WHERE id = ?");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$sale_result = $stmt->get_result();
$sale = $sale_result->fetch_assoc();

if (!$sale) {
    die("Sale not found.");
}

// Fetch associated sale items
$item_stmt = $conn->prepare("SELECT * FROM sales_items WHERE sale_id = ?");
$item_stmt->bind_param("i", $sale['id']);
$item_stmt->execute();
$items_result = $item_stmt->get_result();
$items = [];
while ($item = $items_result->fetch_assoc()) {
    $items[] = $item;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Sale</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <div class="container my-5">
    <h2 class="mb-4">Edit Sale</h2>
    <form method="post" action="api-update-sale.php">
      <input type="hidden" name="sale_id" value="<?= $sale['sale_id'] ?>">

      <div class="mb-3">
        <label for="saleName" class="form-label">Sale Name:</label>
        <input type="text" class="form-control" id="saleName" name="sale_name" value="<?= $sale['sale_name'] ?>" required>
      </div>

      <div class="mb-3">
        <label for="salePhoneNo" class="form-label">Phone Number:</label>
        <input type="text" class="form-control" id="salePhoneNo" name="sale_phone_no" value="<?= $sale['sale_phone_no'] ?>" required>
      </div>

      <div class="mb-3">
        <label for="saleAddress" class="form-label">Address:</label>
        <textarea class="form-control" id="saleAddress" name="sale_address" rows="3" required><?= $sale['sale_address'] ?></textarea>
      </div>

      <div class="mb-3">
        <label for="saleDate" class="form-label">Sale Date:</label>
        <input type="date" class="form-control" id="saleDate" name="sale_date" value="<?= $sale['sale_date'] ?>" required>
      </div>

      <div class="mb-3" id="items">
        <label for="items" class="form-label">Items:</label>
        <?php foreach ($items as $item): ?>
          <div class="d-flex mb-2">
            <input type="text" class="form-control me-2" name="item_name[]" value="<?= $item['item_name'] ?>" required>
            <input type="number" step="0.01" class="form-control me-2" name="item_price[]" value="<?= $item['item_price'] ?>" required>
          </div>
        <?php endforeach; ?>
      </div>

      <button type="button" class="btn btn-outline-primary btn-sm" onclick="addItem()">+ Add Item</button>

      <div class="mb-3">
        <label for="totalDiscount" class="form-label">Total Discount:</label>
        <input type="number" step="0.01" class="form-control" id="totalDiscount" name="total_discount" value="<?= $sale['total_discount'] ?>">
      </div>

      <div class="mb-3">
        <label for="status" class="form-label">Status:</label>
        <select class="form-select" id="status" name="status">
          <option value="Paid" <?= $sale['status'] === 'Paid' ? 'selected' : '' ?>>Paid</option>
          <option value="Not Paid" <?= $sale['status'] === 'Not Paid' ? 'selected' : '' ?>>Not Paid</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="note" class="form-label">Note:</label>
        <textarea class="form-control" id="note" name="note" rows="3"><?= $sale['note'] ?></textarea>
      </div>

      <button type="submit" class="btn btn-primary">Update Sale</button>
    </form>
  </div>

  <!-- Bootstrap JS and Popper.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    function addItem() {
      const div = document.createElement('div');
      div.classList.add('d-flex', 'mb-2');
      div.innerHTML = `<input type="text" class="form-control me-2" name="item_name[]" placeholder="Item Name" required>
                      <input type="number" step="0.01" class="form-control me-2" name="item_price[]" placeholder="Item Price" required>`;
      document.getElementById('items').appendChild(div);
    }
  </script>
</body>
</html>
