<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Sale</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <div class="container my-5">
    <h2 class="mb-4">Add Sale</h2>
    <form method="post" action="api-add-sales.php">
      <div class="mb-3">
        <label for="saleName" class="form-label">Sale Name:</label>
        <input type="text" class="form-control" id="saleName" name="sale_name" required>
      </div>

      <div class="mb-3">
        <label for="salePhoneNo" class="form-label">Phone Number:</label>
        <input type="text" class="form-control" id="salePhoneNo" name="sale_phone_no" required>
      </div>

      <div class="mb-3">
        <label for="saleAddress" class="form-label">Address:</label>
        <textarea class="form-control" id="saleAddress" name="sale_address" rows="3" required></textarea>
      </div>

      <div class="mb-3">
        <label for="saleOtherInfo" class="form-label">Other Info:</label>
        <textarea class="form-control" id="saleOtherInfo" name="sale_other_info" rows="3"></textarea>
      </div>

      <div class="mb-3">
        <label for="saleDate" class="form-label">Sale Date:</label>
        <input type="date" class="form-control" id="saleDate" name="sale_date" required>
      </div>

      <div class="mb-3">
        <label for="items" class="form-label">Items:</label>
        <div id="items">
          <div class="d-flex mb-2">
            <input type="text" class="form-control me-2" name="item_name[]" placeholder="Item Name" required>
            <input type="number" step="0.01" class="form-control me-2" name="item_price[]" placeholder="Item Price" required>
          </div>
        </div>
        <button type="button" class="btn btn-outline-primary btn-sm" onclick="addItem()">+ Add Item</button>
      </div>

      <div class="mb-3">
        <label for="totalDiscount" class="form-label">Total Discount:</label>
        <input type="number" step="0.01" class="form-control" id="totalDiscount" name="total_discount">
      </div>

      <div class="mb-3">
        <label for="status" class="form-label">Status:</label>
        <select class="form-select" id="status" name="status">
          <option value="Paid">Paid</option>
          <option value="Not Paid" selected>Not Paid</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="note" class="form-label">Note:</label>
        <textarea class="form-control" id="note" name="note" rows="3"></textarea>
      </div>

      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>

  <!-- Bootstrap JS and Popper.js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    function addItem() {
      const div = document.createElement('div');
      div.classList.add('d-flex', 'mb-2');
      div.innerHTML = `<input type="text" class="form-control me-2" name="item_name[]" placeholder="Item Name" required>
                      <input type="number" step="0.01" class="form-control me-2" name="item_price[]" placeholder="Item Price" required>`;
      document.getElementById('items').appendChild(div);
    }
  </script>
</body>
</html>
