<?php
require_once 'dompdf/autoload.inc.php'; // Assuming dompdf is in the same directory

use Dompdf\Dompdf;
use Dompdf\Options;

// Initialize DOMPDF
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isPhpEnabled', true);
$dompdf = new Dompdf($options);

// Fetch sale data from the database
require_once 'db.php';
$sale_id = $_GET['sale_id'];
$sql = "SELECT * FROM sales WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$sale_result = $stmt->get_result();
$sale_data = $sale_result->fetch_assoc();

// Fetch items associated with the sale
$item_sql = "SELECT * FROM sales_items WHERE sale_id = ?";
$item_stmt = $conn->prepare($item_sql);
$item_stmt->bind_param("i", $sale_id);
$item_stmt->execute();
$item_result = $item_stmt->get_result();

// Debugging: Check if items exist
if ($item_result->num_rows == 0) {
    echo "No items found for this sale.";
    exit;
}

// Generate HTML for invoice
$html = '
  <html>
  <head>
    <style>
      body {
        font-family: Arial, sans-serif;
      }
      .invoice-header {
        text-align: center;
        margin-bottom: 20px;
      }
      .invoice-header h1 {
        margin: 0;
      }
      .invoice-details {
        margin-bottom: 20px;
      }
      table {
        width: 100%;
        border-collapse: collapse;
      }
      th, td {
        padding: 8px;
        border: 1px solid #ddd;
        text-align: left;
      }
      .total {
        font-weight: bold;
        text-align: right;
      }
      .footer {
        margin-top: 40px;
        display: flex;
        justify-content: space-between;
        font-size: 12px;
      }
      .footer-left {
        width: 50%;
      }
      .footer-right {
        text-align: right;
      }
    </style>
  </head>
  <body>
    <div class="invoice-header">
      <h1>Invoice</h1>
      <p>Sale ID: ' . $sale_data['sale_id'] . '</p>
      <p>Date: ' . $sale_data['sale_date'] . '</p>
    </div>

    <div class="invoice-details">
      <p><strong>Sale Name:</strong> ' . $sale_data['sale_name'] . '</p>
      <p><strong>Phone Number:</strong> ' . $sale_data['sale_phone_no'] . '</p>
      <p><strong>Address:</strong> ' . $sale_data['sale_address'] . '</p>
      <p><strong>Other Info:</strong> ' . $sale_data['sale_other_info'] . '</p>
      <p><strong>Status:</strong> ' . ($sale_data['status'] == 1 ? 'Paid' : 'Not Paid') . '</p>
      <p><strong>Note:</strong> ' . $sale_data['note'] . '</p>
    </div>

    <table>
      <thead>
        <tr>
          <th>Item Name</th>
          <th>Price</th>
        </tr>
      </thead>
      <tbody>';

      // Ensure items are fetched and displayed
      while ($item = $item_result->fetch_assoc()) {
        $html .= '
        <tr>
          <td>' . $item['item_name'] . '</td>
          <td>' . $item['item_price'] . '</td>
        </tr>';
      }

$html .= '</tbody>
    </table>

    <div class="total">
      <p><strong>Total Amount:</strong> ' . $sale_data['sale_total_amount'] . '</p>
      <p><strong>Discount:</strong> ' . $sale_data['total_discount'] . '</p>
      <p><strong>Final Total:</strong> ' . $sale_data['final_total'] . '</p>
    </div>

    <div class="footer">
      <div class="footer-left">
        <p><strong>Name:</strong> Rajendrasinh Pahiyar</p>
        <p><strong>Phone No:</strong> 123-456-7890</p>
        <p><strong>Address:</strong> 1234, Some Street, City</p>
        <p><strong>Bank Account Details:</strong></p>
        <p><strong>Bank Name:</strong> XYZ Bank</p>
        <p><strong>Account Number:</strong> 123456789012</p>
        <p><strong>IFSC Code:</strong> XYZB0001234</p>
      </div>
      <div class="footer-right">
        <p>This is an auto-generated invoice.</p>
        <p><strong>Terms and Conditions:</strong></p>
        <p>1. Payment should be made within 30 days of the invoice date.</p>
        <p>2. Late payments may be subject to a 5% penalty.</p>
        <p>3. All sales are final.</p>
      </div>
    </div>

  </body>
  </html>';

// Load HTML to DOMPDF
$dompdf->loadHtml($html);

// Set paper size (A4)
$dompdf->setPaper('A4', 'portrait');

// Render PDF (first pass)
$dompdf->render();

// Output the generated PDF (force download)
$dompdf->stream("invoice_" . $sale_data['sale_id'] . ".pdf", array("Attachment" => 1));
?>
