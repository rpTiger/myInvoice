<?php
require_once 'db.php';
header('Content-Type: application/json');

// Prepare the SQL query
$sql = "SELECT id, sale_id, sale_name, sale_date, final_total, status FROM sales ORDER BY id DESC";

// Execute the query and check for errors
$result = $conn->query($sql);

if ($result === false) {
    echo json_encode(['status' => 'error', 'message' => 'Query failed: ' . $conn->error]);
    exit;
}

$sales = [];
while ($row = $result->fetch_assoc()) {
    $row['status'] = $row['status'] == 1 ? 'Paid' : 'Not Paid';
    $sales[] = $row;
}

echo json_encode(['status' => 'success', 'sales' => $sales]);
