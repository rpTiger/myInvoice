<?php
$host = 'localhost';       // Change if needed (e.g., '127.0.0.1' or your remote host)
$user = 'root';            // Your DB username
$password = '';            // Your DB password
$database = 'my';  // Replace with your actual DB name

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
