<?php
require_once 'db.php';
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

function respond($status, $message, $extra = []) {
    echo json_encode(array_merge(['status' => $status, 'message' => $message], $extra));
    exit();
}

$sale_name = $_POST['sale_name'] ?? '';
$sale_phone_no = $_POST['sale_phone_no'] ?? '';
$sale_address = $_POST['sale_address'] ?? '';
$sale_other_info = $_POST['sale_other_info'] ?? '';
$sale_date = $_POST['sale_date'] ?? '';
$total_discount = $_POST['total_discount'] ?? 0;
$status = $_POST['status'] === 'Paid' ? 1 : 0;
$note = $_POST['note'] ?? '';
$item_name = $_POST['item_name'] ?? [];
$item_price = $_POST['item_price'] ?? [];

if (!$sale_name || !$sale_phone_no || !$sale_date || empty($item_name) || empty($item_price)) {
    respond('error', 'Missing required fields');
}

$sale_id = 'NX' . date('ymd') . rand(100, 999);
$sale_total_amount = array_sum(array_map('floatval', $item_price));
$final_total = $sale_total_amount - floatval($total_discount);

$sale_sql = "INSERT INTO sales (sale_id, sale_name, sale_address, sale_phone_no, sale_other_info, sale_date, sale_total_amount, total_discount, final_total, note, status, created_date)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
$stmt = $conn->prepare($sale_sql);
$stmt->bind_param("ssssssdddsd", $sale_id, $sale_name, $sale_address, $sale_phone_no, $sale_other_info, $sale_date, $sale_total_amount, $total_discount, $final_total, $note, $status);

if (!$stmt->execute()) {
    respond('error', 'Sale insert failed: ' . $stmt->error);
}
$sale_db_id = $conn->insert_id;

$item_sql = "INSERT INTO sales_items (sale_id, item_name, item_price) VALUES (?, ?, ?)";
$item_stmt = $conn->prepare($item_sql);

foreach ($item_name as $i => $name) {
    $price = floatval($item_price[$i]);
    $item_stmt->bind_param("isd", $sale_db_id, $name, $price);
    if (!$item_stmt->execute()) {
        respond('error', 'Item insert failed: ' . $item_stmt->error);
    }
}

respond('success', 'Sale and items added successfully', [
    'sale_id' => $sale_id,
    'final_total' => $final_total
]);
