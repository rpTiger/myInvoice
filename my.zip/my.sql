-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2025 at 02:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my`
--

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `sale_id` varchar(50) NOT NULL,
  `sale_name` varchar(100) NOT NULL,
  `sale_address` text DEFAULT NULL,
  `sale_phone_no` varchar(20) NOT NULL,
  `sale_other_info` text DEFAULT NULL,
  `sale_date` date NOT NULL,
  `sale_total_amount` decimal(10,2) NOT NULL,
  `total_discount` decimal(10,2) DEFAULT 0.00,
  `final_total` decimal(10,2) NOT NULL,
  `note` text DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `created_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `sale_id`, `sale_name`, `sale_address`, `sale_phone_no`, `sale_other_info`, `sale_date`, `sale_total_amount`, `total_discount`, `final_total`, `note`, `status`, `created_date`) VALUES
(1, 'NX250503599', 'raj', 'test', '8866714242', 'test', '2025-05-01', 7000.00, 500.00, 6500.00, 'sdaf', 0, '2025-05-03 16:08:35'),
(2, 'NX250503113', 'sadfasd', 'asdfasf', '8866714242', 'asfdasdf', '2025-05-01', 6000.00, 700.00, 5300.00, 'asdfsf', 0, '2025-05-03 16:09:40'),
(3, 'NX250503242', 'rajendra', 'rajendara', '8866714240', 'dafadfa', '2025-05-01', 6000.00, 500.00, 5500.00, '0', 0, '2025-05-03 16:18:25'),
(4, 'NX250503524', 'rajendra', 'rajendara', '8866714240', 'dafadfa', '2025-05-01', 5000.00, 500.00, 4500.00, '0', 0, '2025-05-03 16:18:54'),
(5, 'NX250503633', 'asdfasf', 'asdfadsf', '8787878778', 'asdfasdf', '2025-05-01', 50000.00, 1000.00, 49000.00, '0', 1, '2025-05-03 16:19:55'),
(6, 'NX250503797', 'asdfasf', 'asdfadsf', '8787878778', 'asdfasdf', '2025-05-01', 50000.00, 1000.00, 49000.00, 'asdasdasdasd', 1, '2025-05-03 16:21:23'),
(7, 'NX250503345', 'New', 'Address', '8866717172', 'other info', '2025-04-27', 21200.00, 3000.00, 18200.00, 'Discount ', 0, '2025-05-03 16:50:31'),
(8, 'NX250503803', 'New', 'Address', '8866717172', 'other info', '2025-04-27', 21200.00, 3000.00, 18200.00, 'Discount ', 0, '2025-05-03 16:57:15'),
(9, 'NX250503714', 'Rajendrasinh Padhiyar', '78-k Atladra Vadodara 390012', '8200083490', 'other info', '2025-05-02', 16200.00, 500.00, 15700.00, 'domain', 0, '2025-05-03 17:37:44'),
(10, '', 'asdfasdf', 'asdfasf', '8778788778', 'asdfasdf', '2025-05-02', 0.00, 0.00, 0.00, 'asdfasdf', 0, '2025-05-03 17:46:43'),
(11, 'NX250503836', 'asdfasdf', 'asdfasf', '2121121221', 'asdfasfd', '2025-05-01', 4000.00, 300.00, 3700.00, 'asdfasf', 1, '2025-05-03 17:48:42');

-- --------------------------------------------------------

--
-- Table structure for table `sales_items`
--

CREATE TABLE `sales_items` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_items`
--

INSERT INTO `sales_items` (`id`, `sale_id`, `item_name`, `item_price`) VALUES
(1, 8, 'Domain buy', 1200.00),
(2, 8, 'Hostinh', 5000.00),
(3, 8, 'Development', 15000.00),
(4, 9, 'Domain ', 1200.00),
(5, 9, 'Development', 15000.00),
(6, 10, 'asfasdf', 1000.00),
(7, 11, 'asdfasfasf', 5000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sales_items`
--
ALTER TABLE `sales_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD CONSTRAINT `sales_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
