<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice Template</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/foundation-sites@6.6.3/dist/css/foundation.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        .top-bar-title h1 {
            font-size: 2em;
            color: #333;
        }

        .invoice-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .invoice-container table {
            width: 100%;
            border-collapse: collapse;
        }

        .invoice-container th, .invoice-container td {
            padding: 12px 15px;
            text-align: left;
        }

        .invoice-container th {
            background-color: #f2f2f2;
        }

        .invoice-container td {
            border-bottom: 1px solid #f2f2f2;
        }

        .header img {
            max-width: 150px;
        }

        .header h2 {
            font-size: 2em;
            color: #333;
            margin: 0;
        }

        .intro span {
            font-weight: bold;
        }

        .additional-info {
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
        }

        .additional-info .columns {
            width: 48%;
        }

        .totals td {
            font-weight: bold;
            padding-top: 15px;
        }

        .totals td.num {
            font-size: 1.2em;
        }

        .button {
            border-radius: 20px;
        }

        .button.secondary {
            border: 2px solid #ccc;
        }

        .button i {
            margin-right: 5px;
        }

        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 0.9em;
            color: #777;
        }

        .footer a {
            text-decoration: none;
            color: #0056b3;
        }

    </style>
</head>
<body>

<header class="top-bar align-center">
    <div class="top-bar-title">
        <h1>Invoice Template <small>with Foundation Flex-Grid Layout</small></h1>
    </div>
</header>

<div class="row expanded">
    <main class="columns">
        <div class="inner-container">
            <header class="row align-center">
                <a class="button hollow secondary"><i class="fas fa-chevron-left"></i> Go Back to Purchases</a>
                &nbsp;&nbsp;<a class="button"><i class="fas fa-print"></i> Print Invoice</a>
            </header>

            <section class="row">
                <div class="callout large invoice-container">
                    <table class="invoice">
                        <tr class="header">
                            <td>
                                <img src="http://www.travelerie.com/wp-content/uploads/2014/04/PlaceholderLogoBlue.jpg" alt="Company Logo">
                            </td>
                            <td class="align-right">
                                <h2>Invoice</h2>
                            </td>
                        </tr>
                        <tr class="intro">
                            <td>
                                Hello, Philip Brooks.<br>
                                Thank you for your order.
                            </td>
                            <td class="text-right">
                                <span class="num">Order #00302</span><br>
                                October 18, 2017
                            </td>
                        </tr>
                        <tr class="details">
                            <td colspan="2">
                                <table>
                                    <thead>
                                    <tr>
                                        <th class="desc">Item Description</th>
                                        <th class="id">Item ID</th>
                                        <th class="qty">Quantity</th>
                                        <th class="amt">Subtotal</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr class="item">
                                        <td class="desc">Name or Description of item</td>
                                        <td class="id num">MH792AM</td>
                                        <td class="qty">1</td>
                                        <td class="amt">₹100.00</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr class="totals">
                            <td></td>
                            <td>
                                <table>
                                    <tr class="subtotal">
                                        <td class="num">Subtotal</td>
                                        <td class="num">₹100.00</td>
                                    </tr>
                                    <tr class="fees">
                                        <td class="num">Shipping & Handling</td>
                                        <td class="num">₹0.00</td>
                                    </tr>
                                    <tr class="tax">
                                        <td class="num">Tax (7%)</td>
                                        <td class="num">₹7.00</td>
                                    </tr>
                                    <tr class="total">
                                        <td>Total</td>
                                        <td>₹107.00</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>

                    <section class="additional-info">
                        <div class="columns">
                            <h5>Billing Information</h5>
                            <p>Philip Brooks<br>
                                134 Madison Ave.<br>
                                New York NY 00102<br>
                                United States
                            </p>
                        </div>
                        <div class="columns">
                            <h5>Payment Information</h5>
                            <p>Credit Card<br>
                                Card Type: Visa<br>
                                &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; 1234
                            </p>
                        </div>
                    </section>
                </div>
            </section>
        </div>
    </main>
</div>

<footer class="footer">
    <p>&copy; 2021 Your Company | <a href="mailto:info@yourcompany.com">Contact Us</a></p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/foundation-sites@6.6.3/dist/js/foundation.min.js"></script>
</body>
</html>
